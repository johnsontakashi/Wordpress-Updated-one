jQuery(document).ready(function($) {
    'use strict';

    // Phone number formatting
    $(document).on('input', '#monarch_phone', function() {
        let value = this.value.replace(/[^0-9]/g, '');
        if (value.length >= 6) {
            value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
        } else if (value.length >= 3) {
            value = value.replace(/(\d{3})(\d{0,3})/, '($1) $2');
        }
        this.value = value;
    });

    // Lock field and show display mode with Edit button
    function lockField(fieldType) {
        const wrapper = $('#monarch-' + fieldType + '-wrapper');
        const input = wrapper.find('input');
        const inputContainer = wrapper.find('.monarch-field-input');
        const displayContainer = wrapper.find('.monarch-field-display');
        const displayValue = wrapper.find('.monarch-field-value');

        let displayText = input.val();

        // Format the display text
        if (fieldType === 'dob' && displayText) {
            // Format date as MM/DD/YYYY
            const date = new Date(displayText);
            displayText = (date.getMonth() + 1).toString().padStart(2, '0') + '/' +
                          date.getDate().toString().padStart(2, '0') + '/' +
                          date.getFullYear();
        }

        displayValue.text(displayText);
        inputContainer.hide();
        displayContainer.show();
        wrapper.addClass('confirmed');
    }

    // Unlock field for editing
    function unlockField(fieldType) {
        const wrapper = $('#monarch-' + fieldType + '-wrapper');
        const inputContainer = wrapper.find('.monarch-field-input');
        const displayContainer = wrapper.find('.monarch-field-display');

        displayContainer.hide();
        inputContainer.show();
        wrapper.removeClass('confirmed');
        wrapper.find('input').focus();
    }

    // Handle Edit button click
    $(document).on('click', '.monarch-edit-btn', function(e) {
        e.preventDefault();
        const fieldType = $(this).data('field');
        unlockField(fieldType);
    });

    // Lock fields when user leaves the field (blur) if valid
    $(document).on('blur', '#monarch_phone', function() {
        const phone = $(this).val().replace(/[^0-9]/g, '');
        if (phone.length >= 10) {
            lockField('phone');
        }
    });

    $(document).on('blur', '#monarch_dob', function() {
        const dob = $(this).val();
        if (dob) {
            // Validate age (must be 18+)
            const dobDate = new Date(dob);
            const today = new Date();
            let age = today.getFullYear() - dobDate.getFullYear();
            const monthDiff = today.getMonth() - dobDate.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dobDate.getDate())) {
                age--;
            }
            if (age >= 18) {
                lockField('dob');
            }
        }
    });

    // Routing number formatting (numbers only, max 9 digits) - both main form and modal
    $(document).on('input', '#monarch_routing_number, #modal_routing_number', function() {
        this.value = this.value.replace(/[^0-9]/g, '').substring(0, 9);
    });

    // Account number formatting (numbers only) - both main form and modal
    $(document).on('input', '#monarch_account_number, #modal_account_number', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    // Handle method toggle buttons inside modal
    $(document).on('click', '.monarch-modal-method-btn', function(e) {
        e.preventDefault();
        const method = $(this).data('method');

        // Update button states
        $('.monarch-modal-method-btn').removeClass('active');
        $(this).addClass('active');

        // Update hidden field
        $('#monarch_entry_method').val(method);

        // Show/hide sections inside modal
        if (method === 'manual') {
            $('#modal-auto-section').hide();
            $('#modal-manual-section').show();
        } else {
            $('#modal-manual-section').hide();
            $('#modal-auto-section').show();
        }
    });

    // Handle Connect Bank Account button click
    $(document).on('click', '#monarch-connect-bank', function(e) {
        e.preventDefault();

        // Validate required fields first
        if (!validateCustomerInfo()) {
            return false;
        }

        const $button = $(this);
        const $spinner = $('#monarch-connect-spinner');

        // Disable button and show spinner
        $button.prop('disabled', true).text('Connecting...');
        $spinner.show();

        // Gather customer data from billing fields
        // State field can be select or input depending on country
        let billingState = $('#billing_state').val() || '';
        if (!billingState) {
            // Try select element
            billingState = $('select#billing_state').val() || '';
        }
        if (!billingState) {
            // Try input element
            billingState = $('input#billing_state').val() || '';
        }

        const customerData = {
            action: 'monarch_create_organization',
            nonce: monarch_ach_params.nonce,
            monarch_phone: $('#monarch_phone').val(),
            monarch_dob: $('#monarch_dob').val(),
            billing_first_name: $('#billing_first_name').val() || '',
            billing_last_name: $('#billing_last_name').val() || '',
            billing_email: $('#billing_email').val() || '',
            billing_address_1: $('#billing_address_1').val() || '',
            billing_address_2: $('#billing_address_2').val() || '',
            billing_city: $('#billing_city').val() || '',
            billing_state: billingState,
            billing_postcode: $('#billing_postcode').val() || '',
            billing_country: $('#billing_country').val() || ''
        };

        console.log('Customer data being sent:', customerData);

        // Create organization and get bank linking URL
        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: customerData,
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data.bank_linking_url) {
                    // Store organization data
                    $('#monarch_org_id').val(response.data.org_id);

                    // Open bank linking in new window/popup
                    openBankConnectionWindow(response.data.bank_linking_url, response.data.org_id);
                } else {
                    showError(response.data || 'Failed to create organization. Please try again.');
                    $button.prop('disabled', false).text('Connect Bank Account');
                    $spinner.hide();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                showError('Connection error: ' + errorThrown);
                $button.prop('disabled', false).text('Connect Bank Account');
                $spinner.hide();
            }
        });
    });

    // Open bank connection in IFRAME with redirect detection
    // When Yodlee redirects after Continue button, opens a new browser window with success page
    function openBankConnectionWindow(connectionUrl, orgId) {
        let url = connectionUrl;

        console.log('Original bank linking URL from Monarch:', connectionUrl);

        // Get the current page URL for callbacks
        const currentUrl = window.location.href;
        let locationUrl = currentUrl.split('?')[0]; // Clean URL without query params

        // Build callback URL - when Yodlee redirects to this, we'll detect it and open new window
        let callbackUrl = locationUrl + '?monarch_bank_callback=1&org_id=' + orgId;

        // Replace placeholders in URL
        if (url.includes('{redirectUrl}') || url.includes('{price}')) {
            url = url.replace(/\{price\}/g, '100');
            url = url.replace(/\{redirectUrl\}/g, encodeURIComponent(callbackUrl));
            console.log('Replaced URL placeholders - redirectUrl:', callbackUrl);
        }

        console.log('Final iframe URL:', url);

        // Store orgId and callback URL globally
        window.monarchCurrentOrgId = orgId;
        window.monarchCallbackUrl = callbackUrl;

        // Create modal with IFRAME for bank linking
        const modal = $('<div id="bank-connection-modal">' +
            '<div class="monarch-modal-overlay"></div>' +
            '<div class="monarch-modal-content monarch-modal-iframe-content">' +
            '<div class="monarch-modal-header">' +
            '<h3>Connect Your Bank Account</h3>' +
            '<button type="button" id="close-bank-modal" class="monarch-modal-close">&times;</button>' +
            '</div>' +
            // Toggle buttons
            '<div class="monarch-modal-toggle">' +
            '<button type="button" class="monarch-modal-method-btn active" data-method="auto">Automatic (Secure)</button>' +
            '<button type="button" class="monarch-modal-method-btn" data-method="manual">Manual Entry</button>' +
            '</div>' +
            // Automatic section - iframe for bank linking
            '<div id="modal-auto-section" class="monarch-modal-section">' +
            '<div class="monarch-iframe-container">' +
            '<iframe id="monarch-bank-iframe" src="' + url + '" frameborder="0" allowfullscreen></iframe>' +
            '</div>' +
            '<div class="monarch-modal-footer">' +
            '<button type="button" id="monarch-bank-connected-btn" class="button alt">I\'ve Connected My Bank</button>' +
            '</div>' +
            '</div>' +
            // Manual entry section
            '<div id="modal-manual-section" class="monarch-modal-section" style="display:none;">' +
            '<div class="monarch-modal-manual-form">' +
            '<div class="monarch-manual-form-inner">' +
            '<p class="form-row">' +
            '<label for="modal_bank_name">Bank Name <span class="required">*</span></label>' +
            '<input id="modal_bank_name" type="text" placeholder="e.g., Chase, Bank of America">' +
            '</p>' +
            '<p class="form-row form-row-half">' +
            '<label for="modal_routing_number">Routing Number <span class="required">*</span></label>' +
            '<input id="modal_routing_number" type="text" maxlength="9" placeholder="9 digits">' +
            '</p>' +
            '<p class="form-row form-row-half">' +
            '<label for="modal_account_number">Account Number <span class="required">*</span></label>' +
            '<input id="modal_account_number" type="text" placeholder="Your account number">' +
            '</p>' +
            '<p class="form-row">' +
            '<label for="modal_account_type">Account Type <span class="required">*</span></label>' +
            '<select id="modal_account_type">' +
            '<option value="CHECKING">Checking</option>' +
            '<option value="SAVINGS">Savings</option>' +
            '</select>' +
            '</p>' +
            '<div class="monarch-modal-manual-footer">' +
            '<button type="button" id="monarch-manual-submit-modal" class="button alt">Submit Bank Details</button>' +
            '<span id="monarch-manual-spinner-modal" class="spinner" style="display:none;"></span>' +
            '</div>' +
            '<p class="monarch-manual-note">Your bank details are securely transmitted and encrypted.</p>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>');

        $('body').append(modal);

        // Add CSS for iframe modal
        if (!$('#monarch-iframe-style').length) {
            $('head').append('<style id="monarch-iframe-style">' +
                '.monarch-modal-iframe-content { width: 95%; max-width: 920px; height: 85vh; max-height: 85vh; }' +
                '.monarch-iframe-container { flex: 1; min-height: 0; display: flex; background: transparent; overflow: hidden; }' +
                '#monarch-bank-iframe { width: 100%; height: 100%; border: none; background: transparent; }' +
                '#modal-auto-section { display: flex; flex-direction: column; flex: 1; min-height: 0; overflow: hidden; }' +
                '</style>');
        }

        // Close modal handler
        $(document).on('click', '#close-bank-modal', function() {
            if (window.monarchIframeMonitor) {
                clearInterval(window.monarchIframeMonitor);
            }
            window.removeEventListener('message', handleBankMessage);
            $('#bank-connection-modal').remove();
            $('#monarch-connect-bank').prop('disabled', false).text('Connect Bank Account');
            $('#monarch-connect-spinner').hide();
        });

        // Close on overlay click
        $(document).on('click', '.monarch-modal-overlay', function() {
            if (window.monarchIframeMonitor) {
                clearInterval(window.monarchIframeMonitor);
            }
            window.removeEventListener('message', handleBankMessage);
            $('#bank-connection-modal').remove();
            $('#monarch-connect-bank').prop('disabled', false).text('Connect Bank Account');
            $('#monarch-connect-spinner').hide();
        });

        // Handle "I've Connected My Bank" button
        $(document).on('click', '#monarch-bank-connected-btn', function() {
            $(this).prop('disabled', true).text('Verifying...');
            checkBankConnectionStatus(orgId);
        });

        // Listen for postMessage from iframe
        window.addEventListener('message', handleBankMessage);

        // Monitor iframe for navigation events
        // When Yodlee clicks Continue, it tries to redirect - we detect this and open success window
        const iframe = document.getElementById('monarch-bank-iframe');
        let redirectDetected = false;
        let iframeLoadCount = 0;

        // Handle iframe load events - each load after the first indicates navigation
        $(iframe).on('load', function() {
            iframeLoadCount++;
            console.log('Iframe load event #' + iframeLoadCount);

            // Skip the first load (initial page load)
            if (iframeLoadCount === 1) {
                console.log('Initial iframe load - Monarch bank linking page');
                return;
            }

            // Second or later load means navigation occurred (Continue was clicked)
            if (!redirectDetected) {
                redirectDetected = true;
                console.log('Navigation detected in iframe - opening success window');

                // Try to check if we can read the URL (same-origin)
                try {
                    const iframeUrl = iframe.contentWindow.location.href;
                    console.log('Iframe navigated to:', iframeUrl);

                    // If it's our callback URL, open success window
                    if (iframeUrl.includes('monarch_bank_callback=1') || iframeUrl.includes('localhost')) {
                        openSuccessWindow(callbackUrl);
                        return;
                    }
                } catch (e) {
                    // CORS blocked - still open success window since navigation happened
                    console.log('CORS blocked, but navigation detected - opening success window');
                }

                // Open success window regardless since Continue was clicked
                openSuccessWindow(callbackUrl);
            }
        });

        // Store reference for cleanup
        window.monarchIframeLoadCount = iframeLoadCount;
    }

    // Open success page in a new browser window
    function openSuccessWindow(callbackUrl) {
        console.log('Opening success page in new window:', callbackUrl);

        // Open the success page in a new browser window
        const successWindow = window.open(
            callbackUrl,
            'MonarchBankSuccess',
            'width=500,height=600,left=' + ((screen.width - 500) / 2) + ',top=' + ((screen.height - 600) / 2) + ',scrollbars=yes,resizable=yes'
        );

        if (successWindow) {
            // Update modal to show waiting for success window
            $('.monarch-iframe-container').html(
                '<div class="monarch-popup-waiting">' +
                '<div class="monarch-spinner-large"></div>' +
                '<h4>Bank Linking Complete!</h4>' +
                '<p>Please confirm in the new window that opened.</p>' +
                '<p class="monarch-popup-note">If the window was blocked, <a href="#" id="open-success-window">click here to open it</a>.</p>' +
                '</div>'
            );

            // Add CSS for spinner if not already added
            if (!$('#monarch-spinner-style').length) {
                $('head').append('<style id="monarch-spinner-style">' +
                    '.monarch-popup-waiting { text-align: center; padding: 40px 20px; }' +
                    '.monarch-spinner-large { width: 50px; height: 50px; border: 4px solid #f3f3f3; border-top: 4px solid #0073aa; border-radius: 50%; animation: monarch-spin 1s linear infinite; margin: 0 auto 20px; }' +
                    '@keyframes monarch-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }' +
                    '.monarch-popup-waiting h4 { margin: 0 0 10px; color: #333; }' +
                    '.monarch-popup-waiting p { color: #666; margin: 5px 0; }' +
                    '.monarch-popup-note { font-size: 12px; margin-top: 15px !important; }' +
                    '</style>');
            }

            // Handle click to reopen success window
            $(document).on('click', '#open-success-window', function(e) {
                e.preventDefault();
                window.open(callbackUrl, 'MonarchBankSuccess', 'width=500,height=600,scrollbars=yes,resizable=yes');
            });
        } else {
            alert('Please allow popups for this site to complete bank linking.');
        }
    }

    // Handle messages from Monarch iframe
    // Supports Yodlee FastLink 4 callbacks: onSuccess, onClose, onError, onEvent
    // See: https://developer.yodlee.com/docs/fastlink/4.0/advanced
    function handleBankMessage(event) {
        try {
            // Log all messages for debugging
            console.log('Received postMessage from:', event.origin, 'Data:', event.data);

            // Only accept messages from trusted Monarch/Yodlee domains
            const allowedOrigins = [
                'https://devapi.monarch.is',
                'https://api.monarch.is',
                'https://appsandbox.monarch.is',
                'https://app.monarch.is',
                'https://dag2.yodlee.com',
                'https://fl4.prod.yodlee.com',
                'https://node.yodlee.com',
                'https://fastlink.yodlee.com',
                'https://finapp.yodlee.com',
                'https://aggregation.yodlee.com'
            ];

            const isAllowed = allowedOrigins.some(origin =>
                event.origin.startsWith(origin) ||
                event.origin.includes('yodlee') ||
                event.origin.includes('monarch') ||
                event.origin.includes('envestnet')
            );

            if (!isAllowed) {
                console.log('Message from non-allowed origin, ignoring:', event.origin);
                return;
            }

            console.log('Allowed origin - processing message');

            // Skip focus-related messages
            if (event.data && event.data.action === 'focus') {
                return;
            }

            // Parse message data
            let messageData = event.data;
            if (typeof event.data === 'string') {
                try {
                    messageData = JSON.parse(event.data);
                } catch (e) {
                    // Not JSON, check for specific strings
                    if (event.data.includes('SUCCESS') || event.data.includes('COMPLETE')) {
                        console.log('Bank linking success detected from string message');
                        triggerBankVerification();
                        return;
                    }
                    return;
                }
            }

            if (!messageData || typeof messageData !== 'object') {
                return;
            }

            // =====================================================
            // Handle Yodlee FastLink 4 callback events
            // =====================================================

            // onSuccess callback - account successfully added
            // Contains: providerAccountId, requestId, status='SUCCESS', additionalStatus
            if (messageData.fnToCall === 'onSuccess' ||
                (messageData.status === 'SUCCESS' && messageData.providerAccountId)) {
                console.log('FastLink onSuccess callback received:', messageData);
                console.log('Provider Account ID:', messageData.providerAccountId);
                triggerBankVerification();
                return;
            }

            // onClose callback - user closed or completed flow
            // Contains: action, sites array, status
            if (messageData.fnToCall === 'onClose' || messageData.fnToCall === 'close') {
                console.log('FastLink onClose callback received:', messageData);
                // Check if there are successfully linked sites
                if (messageData.sites && messageData.sites.length > 0) {
                    const successSites = messageData.sites.filter(s => s.status === 'SUCCESS');
                    if (successSites.length > 0) {
                        console.log('Successfully linked sites found:', successSites);
                        triggerBankVerification();
                        return;
                    }
                }
                // User closed without completing - still check in case linking completed
                if (messageData.action !== 'exit' || messageData.status === 'SUCCESS') {
                    triggerBankVerification();
                }
                return;
            }

            // onError callback - error occurred
            if (messageData.fnToCall === 'onError') {
                console.log('FastLink onError callback received:', messageData);
                console.error('FastLink error:', messageData.code, messageData.message);
                // Don't automatically fail - let user retry or use manual
                return;
            }

            // onEvent callback - intermediate status updates
            if (messageData.fnToCall === 'onEvent') {
                console.log('FastLink onEvent callback received:', messageData);
                // Could show progress to user here
                return;
            }

            // =====================================================
            // Handle other message formats (legacy/Monarch-specific)
            // =====================================================

            // Yodlee accountStatus function call
            if (messageData.fnToCall === 'accountStatus') {
                console.log('accountStatus callback received');
                triggerBankVerification();
                return;
            }

            // POST_MESSAGE type from Yodlee
            if (messageData.type === 'POST_MESSAGE') {
                console.log('POST_MESSAGE received, checking for success indicators');
                if (messageData.providerAccountId || messageData.status === 'SUCCESS') {
                    triggerBankVerification();
                }
                return;
            }

            // Sites array present (Yodlee success indicator)
            if (messageData.sites && Array.isArray(messageData.sites)) {
                console.log('Sites array received:', messageData.sites);
                triggerBankVerification();
                return;
            }

            // Provider account linked
            if (messageData.providerAccountId && messageData.providerId) {
                console.log('Provider account linked:', messageData.providerAccountId);
                triggerBankVerification();
                return;
            }

            // Direct PayToken from Monarch
            const payTokenId = messageData.payTokenId || messageData.paytoken_id || messageData.paytokenId || messageData._id;
            if (payTokenId) {
                console.log('Received PayToken ID directly:', payTokenId);
                completeBankConnection(payTokenId);
                return;
            }

            // Exit action
            if (messageData.action === 'exit') {
                console.log('Exit action received, checking bank status...');
                triggerBankVerification();
                return;
            }

            // Handle our own callback page messages (from redirect)
            if (messageData.type === 'MONARCH_BANK_CALLBACK') {
                console.log('Monarch bank callback received:', messageData);

                if (messageData.status === 'SUCCESS') {
                    // Bank linking complete with paytoken - finalize connection
                    if (messageData.paytoken_id) {
                        console.log('Bank linked with paytoken:', messageData.paytoken_id);
                        completeBankConnection(messageData.paytoken_id);
                    } else {
                        // Success without paytoken - trigger verification
                        triggerBankVerification();
                    }
                    return;
                }

                if (messageData.status === 'LANDED') {
                    // User landed on callback page - update UI to show progress
                    console.log('User landed on callback page, waiting for them to click confirm');
                    $('#monarch-bank-connected-btn').text('Waiting for confirmation...');
                    return;
                }
            }

            // Generic success indicators
            if (messageData.type === 'BANK_CONNECTION_SUCCESS' ||
                messageData.success === true ||
                messageData.action === 'bankConnected' ||
                messageData.status === 'SUCCESS') {
                console.log('Bank connection success indicator received');
                triggerBankVerification();
                return;
            }

            console.log('Unhandled message format:', messageData);

        } catch (error) {
            console.error('Error handling postMessage:', error);
        }
    }

    // Trigger bank verification with a small delay
    function triggerBankVerification() {
        $('#monarch-bank-connected-btn').text('Connection Successful! Verifying...').addClass('success-pulse');
        setTimeout(function() {
            if ($('#monarch-bank-connected-btn').length && !$('#monarch-bank-connected-btn').prop('disabled')) {
                $('#monarch-bank-connected-btn').click();
            }
        }, 1500);
    }

    // Check if bank connection was successful
    // This calls the /v1/getlatestpaytoken/[organizationID] endpoint
    // Per Monarch embedded bank linking documentation
    // Includes retry logic since paytoken may take a moment to be available after bank linking
    function checkBankConnectionStatus(orgId, retryCount) {
        retryCount = retryCount || 0;
        const maxRetries = 5; // Increased retries
        const retryDelay = 3000; // 3 seconds between retries (bank linking can take time)

        console.log('Checking bank connection status for org:', orgId, '(attempt', retryCount + 1, 'of', maxRetries + 1, ')');

        $('#monarch-bank-connected-btn').text('Verifying... ' + (retryCount > 0 ? '(Attempt ' + (retryCount + 1) + ')' : ''));

        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: {
                action: 'monarch_get_latest_paytoken',
                nonce: monarch_ach_params.nonce,
                org_id: orgId
            },
            dataType: 'json',
            success: function(response) {
                console.log('getLatestPayToken response:', response);

                if (response.success && response.data.paytoken_id) {
                    // Successfully retrieved paytoken - bank linking is complete
                    console.log('Bank linked successfully, paytoken:', response.data.paytoken_id);
                    completeBankConnection(response.data.paytoken_id);
                } else {
                    // PayToken not found - might need to retry
                    var errorMsg = response.data || 'PayToken not found';
                    console.log('PayToken not found:', errorMsg);
                    console.log('Full response object:', JSON.stringify(response, null, 2));

                    if (retryCount < maxRetries) {
                        // Retry after delay - paytoken may not be immediately available
                        console.log('Retrying in', retryDelay, 'ms...');
                        $('#monarch-bank-connected-btn').text('Verifying... Please wait (' + (maxRetries - retryCount) + ' attempts remaining)');
                        setTimeout(function() {
                            checkBankConnectionStatus(orgId, retryCount + 1);
                        }, retryDelay);
                    } else {
                        // Max retries reached - show detailed error
                        console.error('Max retries reached. Error details:', errorMsg);
                        var errorDetails = 'Bank connection not detected after ' + (maxRetries + 1) + ' attempts.\n\n';
                        errorDetails += 'Possible reasons:\n';
                        errorDetails += '1. Bank linking was not completed in the iframe\n';
                        errorDetails += '2. The PayToken is still being processed\n';
                        errorDetails += '3. There may be a credentials mismatch\n\n';
                        errorDetails += 'Technical details: ' + errorMsg + '\n\n';
                        errorDetails += 'Please try:\n';
                        errorDetails += '- Using the "Manual Entry" option instead\n';
                        errorDetails += '- Refreshing the page and trying again';
                        alert(errorDetails);
                        $('#monarch-bank-connected-btn').prop('disabled', false).text('I\'ve Connected My Bank');
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error('Error retrieving paytoken:', error);
                console.error('XHR response:', xhr.responseText);

                if (retryCount < maxRetries) {
                    // Retry on error
                    console.log('Request error, retrying in', retryDelay, 'ms...');
                    setTimeout(function() {
                        checkBankConnectionStatus(orgId, retryCount + 1);
                    }, retryDelay);
                } else {
                    alert('Failed to verify bank connection after multiple attempts.\n\nError: ' + error + '\n\nPlease try using the "Manual Entry" option instead.');
                    $('#monarch-bank-connected-btn').prop('disabled', false).text('I\'ve Connected My Bank');
                }
            }
        });
    }

    // Complete bank connection after successful linking
    function completeBankConnection(payTokenId) {
        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: {
                action: 'monarch_bank_connection_complete',
                nonce: monarch_ach_params.nonce,
                paytoken_id: payTokenId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update form with connection data
                    $('#monarch_org_id').val(response.data.org_id);
                    $('#monarch_paytoken_id').val(response.data.paytoken_id);
                    $('#monarch_bank_verified').val('true');

                    // Close modal
                    $('#bank-connection-modal').remove();
                    window.removeEventListener('message', handleBankMessage);

                    // Refresh checkout to show connected status
                    location.reload();
                } else {
                    showError(response.data || 'Failed to complete bank connection');
                    $('#monarch-bank-connected-btn').prop('disabled', false).text('I\'ve Connected My Bank');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                showError('Connection error: ' + errorThrown);
                $('#monarch-bank-connected-btn').prop('disabled', false).text('I\'ve Connected My Bank');
            }
        });
    }

    // Show bank connected UI
    function showBankConnectedUI() {
        $('#monarch-ach-form').html(
            '<div class="monarch-bank-connected">' +
            '<p><strong> Bank account connected</strong></p>' +
            '<p>Your bank account has been verified. You can now complete your order.</p>' +
            '</div>'
        );
        $('#monarch-connect-bank').prop('disabled', false).text('Connect Bank Account');
        $('#monarch-connect-spinner').hide();
    }

    // Validate customer information
    function validateCustomerInfo() {
        let isValid = true;
        hideError();

        // Clear previous error states
        $('#monarch-ach-form input').removeClass('error');

        // Check billing fields
        if (!$('#billing_first_name').val() || !$('#billing_last_name').val()) {
            showError('Please fill in your billing name above first.');
            return false;
        }

        if (!$('#billing_email').val()) {
            showError('Please fill in your email address above first.');
            return false;
        }

        // Check billing address fields required by Monarch
        if (!$('#billing_address_1').val()) {
            showError('Please fill in your billing address above first.');
            return false;
        }

        if (!$('#billing_city').val()) {
            showError('Please fill in your billing city above first.');
            return false;
        }

        // State field can be select or input
        let billingState = $('#billing_state').val() || $('select#billing_state').val() || $('input#billing_state').val() || '';
        if (!billingState) {
            showError('Please select your billing state/province above first.');
            return false;
        }

        if (!$('#billing_postcode').val()) {
            showError('Please fill in your billing postcode/ZIP above first.');
            return false;
        }

        // Required field validation
        const requiredFields = [
            {id: 'monarch_phone', message: 'Phone number is required'},
            {id: 'monarch_dob', message: 'Date of birth is required'}
        ];

        requiredFields.forEach(function(field) {
            const $field = $('#' + field.id);
            if (!$field.val() || $field.val().trim() === '') {
                $field.addClass('error');
                if (isValid) {
                    showError(field.message);
                }
                isValid = false;
            }
        });

        if (!isValid) {
            return false;
        }

        // Phone number validation
        const phone = $('#monarch_phone').val().replace(/[^0-9]/g, '');
        if (phone.length < 10) {
            $('#monarch_phone').addClass('error');
            showError('Please enter a valid 10-digit phone number');
            return false;
        }

        // Date of birth validation (must be 18+)
        const dob = new Date($('#monarch_dob').val());
        const today = new Date();
        let age = today.getFullYear() - dob.getFullYear();
        const monthDiff = today.getMonth() - dob.getMonth();

        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
            age--;
        }

        if (age < 18) {
            $('#monarch_dob').addClass('error');
            showError('You must be at least 18 years old');
            return false;
        }

        return true;
    }

    // Form validation before checkout submission
    $(document).on('checkout_place_order_monarch_ach', function() {
        const $orgId = $('#monarch_org_id, input[name="monarch_org_id"]');
        const $payTokenId = $('#monarch_paytoken_id, input[name="monarch_paytoken_id"]');

        // Check if bank is connected (either from user meta or form)
        if ((!$orgId.val() || !$payTokenId.val()) && !$('.monarch-bank-connected').length) {
            showError('Please connect your bank account before placing your order.');
            return false;
        }

        return true;
    });

    function showError(message) {
        let $errorDiv = $('#monarch-ach-errors');
        if (!$errorDiv.length) {
            $errorDiv = $('<div id="monarch-ach-errors" class="woocommerce-error"></div>');
            // Try to prepend to form, or to bank-connected div, or to payment method
            if ($('#monarch-ach-form').length) {
                $('#monarch-ach-form').prepend($errorDiv);
            } else if ($('.monarch-bank-connected').length) {
                $('.monarch-bank-connected').before($errorDiv);
            } else {
                $('.payment_method_monarch_ach').append($errorDiv);
            }
        }
        $errorDiv.html(message).show();

        if ($errorDiv.length && $errorDiv.offset()) {
            $('html, body').animate({
                scrollTop: $errorDiv.offset().top - 100
            }, 500);
        }
    }

    function hideError() {
        $('#monarch-ach-errors').hide();
    }

    // Handle Manual Bank Entry submit from modal
    $(document).on('click', '#monarch-manual-submit-modal', function(e) {
        e.preventDefault();

        // Validate bank fields from modal
        if (!validateModalBankFields()) {
            return false;
        }

        const $button = $(this);
        const $spinner = $('#monarch-manual-spinner-modal');

        // Disable button and show spinner
        $button.prop('disabled', true).text('Processing...');
        $spinner.show();

        // Gather data from modal fields
        let billingState = $('#billing_state').val() || '';
        if (!billingState) {
            billingState = $('select#billing_state').val() || '';
        }
        if (!billingState) {
            billingState = $('input#billing_state').val() || '';
        }

        const requestData = {
            action: 'monarch_manual_bank_entry',
            nonce: monarch_ach_params.nonce,
            monarch_phone: $('#monarch_phone').val(),
            monarch_dob: $('#monarch_dob').val(),
            bank_name: $('#modal_bank_name').val(),
            routing_number: $('#modal_routing_number').val(),
            account_number: $('#modal_account_number').val(),
            account_type: $('#modal_account_type').val(),
            billing_first_name: $('#billing_first_name').val() || '',
            billing_last_name: $('#billing_last_name').val() || '',
            billing_email: $('#billing_email').val() || '',
            billing_address_1: $('#billing_address_1').val() || '',
            billing_address_2: $('#billing_address_2').val() || '',
            billing_city: $('#billing_city').val() || '',
            billing_state: billingState,
            billing_postcode: $('#billing_postcode').val() || '',
            billing_country: $('#billing_country').val() || ''
        };

        console.log('Manual bank entry data:', requestData);

        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: requestData,
            dataType: 'json',
            success: function(response) {
                console.log('Manual bank entry response:', response);
                if (response.success) {
                    // Update form with connection data
                    $('#monarch_org_id').val(response.data.org_id);
                    $('#monarch_paytoken_id').val(response.data.paytoken_id);
                    $('#monarch_bank_verified').val('true');

                    // Close modal and refresh checkout
                    $('#bank-connection-modal').remove();
                    location.reload();
                } else {
                    showModalError(response.data || 'Failed to connect bank account. Please try again.');
                    $button.prop('disabled', false).text('Submit Bank Details');
                    $spinner.hide();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('Manual bank entry error:', textStatus, errorThrown, jqXHR.responseText);
                showModalError('Connection error: ' + errorThrown);
                $button.prop('disabled', false).text('Submit Bank Details');
                $spinner.hide();
            }
        });
    });

    // Validate bank fields from modal
    function validateModalBankFields() {
        // Clear previous error states
        $('#modal-manual-section input, #modal-manual-section select').removeClass('error');

        const bankName = $('#modal_bank_name').val();
        const routingNumber = $('#modal_routing_number').val();
        const accountNumber = $('#modal_account_number').val();

        if (!bankName || bankName.trim() === '') {
            $('#modal_bank_name').addClass('error');
            showModalError('Bank name is required');
            return false;
        }

        if (!routingNumber || routingNumber.length !== 9) {
            $('#modal_routing_number').addClass('error');
            showModalError('Routing number must be exactly 9 digits');
            return false;
        }

        if (!accountNumber || accountNumber.trim() === '') {
            $('#modal_account_number').addClass('error');
            showModalError('Account number is required');
            return false;
        }

        return true;
    }

    // Show error inside modal
    function showModalError(message) {
        let $errorDiv = $('#monarch-modal-errors');
        if (!$errorDiv.length) {
            $errorDiv = $('<div id="monarch-modal-errors" class="monarch-modal-error"></div>');
            $('.monarch-manual-form-inner').prepend($errorDiv);
        }
        $errorDiv.html(message).show();
    }

    // Handle returning user "Continue with Bank" button
    // This is for users who have org_id but their paytoken expired after a transaction
    $(document).on('click', '#monarch-reconnect-bank', function(e) {
        e.preventDefault();

        const $button = $(this);
        const $spinner = $('#monarch-reconnect-spinner');
        const orgId = $('#monarch_org_id').val();

        if (!orgId) {
            showError('Organization ID not found. Please refresh the page.');
            return;
        }

        // Disable button and show spinner
        $button.prop('disabled', true).text('Connecting...');
        $spinner.show();

        // For returning users, we need to get a new paytoken
        // Call getLatestPayToken to get the bank linking URL or paytoken
        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: {
                action: 'monarch_get_bank_linking_url',
                nonce: monarch_ach_params.nonce,
                org_id: orgId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data.bank_linking_url) {
                    // Open bank linking modal
                    openBankConnectionWindow(response.data.bank_linking_url, orgId);
                } else if (response.success && response.data.paytoken_id) {
                    // User already has a valid paytoken (rare case)
                    $('#monarch_paytoken_id').val(response.data.paytoken_id);
                    location.reload();
                } else if (!response.success && response.data && response.data.action === 'show_registration_form') {
                    // Bank connection expired - need to re-register
                    // Reload the page to show the registration form (data has been cleared server-side)
                    showError(response.data.message || 'Please complete registration to reconnect your bank.');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    var errorMsg = (response.data && response.data.message) ? response.data.message : (response.data || 'Failed to get bank linking URL. Please try again.');
                    showError(errorMsg);
                    $button.prop('disabled', false).text('Continue with Bank');
                    $spinner.hide();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                showError('Connection error: ' + errorThrown);
                $button.prop('disabled', false).text('Continue with Bank');
                $spinner.hide();
            }
        });
    });

    // Handle "Use a different bank account" for returning users
    $(document).on('click', '#monarch-use-different-bank', function(e) {
        e.preventDefault();

        if (!confirm('This will disconnect your current bank account. You will need to go through the full setup again. Continue?')) {
            return;
        }

        const $link = $(this);
        $link.text('Disconnecting...').css('pointer-events', 'none');

        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: {
                action: 'monarch_disconnect_bank',
                nonce: monarch_ach_params.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    showError(response.data || 'Failed to disconnect bank account');
                    $link.text('Use a different bank account').css('pointer-events', 'auto');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                showError('Connection error: ' + errorThrown);
                $link.text('Use a different bank account').css('pointer-events', 'auto');
            }
        });
    });

    // Handle disconnect bank account click
    $(document).on('click', '#monarch-disconnect-bank', function(e) {
        e.preventDefault();
        console.log('Disconnect bank clicked');

        if (!confirm('Are you sure you want to disconnect your bank account? You will need to connect again.')) {
            return;
        }

        const $link = $(this);
        $link.text('Disconnecting...').css('pointer-events', 'none');

        console.log('Sending disconnect request to:', monarch_ach_params.ajax_url);

        $.ajax({
            url: monarch_ach_params.ajax_url,
            method: 'POST',
            data: {
                action: 'monarch_disconnect_bank',
                nonce: monarch_ach_params.nonce
            },
            dataType: 'json',
            success: function(response) {
                console.log('Disconnect response:', response);
                if (response.success) {
                    location.reload();
                } else {
                    showError(response.data || 'Failed to disconnect bank account');
                    $link.text('Use a different bank account').css('pointer-events', 'auto');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('Disconnect error:', textStatus, errorThrown, jqXHR.responseText);
                showError('Connection error: ' + errorThrown);
                $link.text('Use a different bank account').css('pointer-events', 'auto');
            }
        });
    });

    // Auto-fill form with test data in development mode
    if (typeof monarch_ach_params !== 'undefined' && monarch_ach_params.test_mode === 'yes') {
        // Test mode is active - could add debug helpers here
    }

    // Listen for WooCommerce checkout errors and auto-refresh if bank connection expired
    $(document.body).on('checkout_error', function() {
        // Check if the error message contains "bank connection has expired"
        var errorText = $('.woocommerce-error').text();
        if (errorText.indexOf('bank connection has expired') !== -1 ||
            errorText.indexOf('Please reconnect your bank') !== -1) {
            // Show a message and reload after 2 seconds
            setTimeout(function() {
                location.reload();
            }, 2000);
        }
    });
});
